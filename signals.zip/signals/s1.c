
#include "stdio.h"

#include <signal.h>

int global = 100; 

void my_sigchld_handler(int signum)
{
  printf("hi this is my sigchld handler signum %d \n", signum);
  
  global = 101;

  return;
}

void my_sigalrm_handler(int signum)
{
  printf("hi this is my sigalrm handler signum %d \n", signum);
  
  global = 102;

  return;
}

int main()
{

  printf("Pid = %d \n", getpid());

  signal(SIGCHLD, my_sigchld_handler);
  signal(SIGALRM, my_sigalrm_handler);

  while(1)
  {
    if (global == 101)
      break;
    
    if (global == 102)
    {
      sleep(3);
      continue;
    }

    sleep(5);

    printf("inside loop\n");
  }

  printf("outside loop\n");
  return 0;
}
