
#include "stdio.h"

#include <signal.h>

int main()
{
  pid_t pid;

  printf("sending signal to p1 enter pid of p1 \n");
  scanf("%d", &pid);

  printf("sending SIGALRM signal to p1 enter pid of p1 \n");
  kill(pid, SIGALRM);

  sleep(10);

  printf("sending SIGCHLD signal to p1 enter pid of p1 \n");
  kill(pid, SIGCHLD);

  return 0;
}
