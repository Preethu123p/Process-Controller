
#include "stdio.h"

#include <signal.h>

int main()
{

  printf("sending signal to p1 : my pid = %d \n", getpid());

  int pid;

  scanf("%d",&pid);

  kill(pid, SIGCHLD);

  return 0;
}
