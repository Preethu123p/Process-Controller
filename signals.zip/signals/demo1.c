
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main()
{
  int i = 1;
  printf("Pid = %d \n", getpid());

  while(1)
  {
    sleep(5);

    printf("Inside loop: %d \n", i++);
  }

  printf("outside loop\n");
  return 0;
}
