
#include "stdio.h"

#include <signal.h>

#if 0
struct sigaction 
{
  void     (*sa_handler)(int);
  void     (*sa_sigaction)(int, siginfo_t *, void *);
  sigset_t   sa_mask;
  int        sa_flags;
  void     (*sa_restorer)(void);
};
#endif 

void my_sigaction_handler_2 (int val, siginfo_t *sig_info, void *context)
{

  printf("Signal Number New Handler : %d \n", val);

  printf("SigInfo: \n");
  printf("  PID:      %d \n", sig_info->si_pid);
  printf("  SIGNO:    %d \n", sig_info->si_signo);
  printf("  SIGCODE:  %d \n", sig_info->si_code);
  return;
}
void my_sigaction_handler(int val, siginfo_t *sig_info, void *context)
{

  printf("Signal Number : %d \n", val);

  printf("SigInfo: \n");
  printf("  PID:      %d \n", sig_info->si_pid);
  printf("  SIGNO:    %d \n", sig_info->si_signo);
  printf("  SIGCODE:  %d \n", sig_info->si_code);

  return;
}

int main()
{

  struct sigaction sa1, sa2, sa3; 
  siginfo_t sa_info;

  sa1.sa_sigaction = my_sigaction_handler; 
  sa1.sa_flags = SA_SIGINFO;
  sa1.sa_restorer = NULL;
  
  sa2.sa_sigaction = my_sigaction_handler_2;
  sa2.sa_flags = SA_SIGINFO;
  sa2.sa_restorer = NULL;

  sigaction(SIGCHLD, &sa1, NULL);
  int i=0;

  while(1)
  {

    printf("Inside P1 loop pid = %d\n", getpid());
    sleep(1);
    
    if (i++ == 10)
      sigaction(SIGCHLD, &sa2, &sa3);
  }

  return 0;
}
